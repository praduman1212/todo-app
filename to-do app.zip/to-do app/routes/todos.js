const express = require('express');
const Todo = require('../models/Todo');
const authenticateToken = require('../middleware/auth');

const router = express.Router();

router.use(authenticateToken);

// Create a new to-do item
router.post('/', async (req, res) => {
    const { title, description } = req.body;
    const newTodo = new Todo({
        userId: req.user.userId,
        title,
        description
    });
    await newTodo.save();
    res.status(201).json(newTodo);
});

// Retrieve all to-do items for the logged-in user
router.get('/', async (req, res) => {
    const todos = await Todo.find({ userId: req.user.userId });
    res.json(todos);
});

// Update a to-do item by ID
router.put('/:id', async (req, res) => {
    const { id } = req.params;
    const { title, description, completed } = req.body;
    const updatedTodo = await Todo.findOneAndUpdate(
        { _id: id, userId: req.user.userId },
        { title, description, completed },
        { new: true }
    );
    if (!updatedTodo) return res.status(404).json({ error: 'To-do item not found' });
    res.json(updatedTodo);
});

// Delete a to-do item by ID
router.delete('/:id', async (req, res) => {
    const { id } = req.params;
    const deletedTodo = await Todo.findOneAndDelete({ _id: id, userId: req.user.userId });
    if (!deletedTodo) return res.status(404).json({ error: 'To-do item not found' });
    res.json({ message: 'To-do item deleted' });
});

module.exports = router;
